#!/bin/sh

cd ..
make clean
make CSS=css/infodoc-styles.css
