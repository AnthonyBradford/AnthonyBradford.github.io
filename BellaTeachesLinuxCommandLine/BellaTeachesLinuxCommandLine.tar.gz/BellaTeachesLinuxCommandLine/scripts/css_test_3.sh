#!/bin/sh

cd ..
make clean
make CSS=css/datamash-texinfo.css
