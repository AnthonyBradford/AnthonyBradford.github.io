#!/bin/sh

cd ..
make clean
make CSS=css/bright-colors.css
