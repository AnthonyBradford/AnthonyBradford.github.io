#!/bin/sh

cd ..
make clean
make CSS=css/janix-texinfo.css
