#!/bin/sh

cd ..
make clean
make CSS=css/sirgazil-document-1.0.1.css
